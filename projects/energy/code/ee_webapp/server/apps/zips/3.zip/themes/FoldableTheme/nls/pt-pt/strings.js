define({
  "_themeLabel": "Tema Dobrável",
  "_layout_default": "Layout predefinido",
  "_layout_layout1": "Layout 1"
});